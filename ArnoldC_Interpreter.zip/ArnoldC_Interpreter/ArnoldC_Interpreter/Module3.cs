﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArnoldC_Interpreter
{
    class Module3
    {

        Tuple<Boolean, String, int> error = new Tuple<bool, string, int>(false, String.Empty, 0);
        List<Tuple<String, String>> GUIActions = new List<Tuple<string, string>>();
        List<Tuple<String, String>> symbolTableList = new List<Tuple<string, string>>();

        public void SemanticAnalysis(List<Tuple<String, String, int>> dataForSemanticAnalyzer)
        {
            List<Tuple<String, String, int>>programData = dataForSemanticAnalyzer;

            //functions

            //program
            for(int i = 0; i<programData.Count; i++)
            {
                String lexeme = programData.ElementAt(i).Item1;
                String lexInfo = programData.ElementAt(i).Item2;
                int lineNum = programData.ElementAt(i).Item3;

                String nextLexeme;
                String nextLexInfo;
                int nextLineNum;

                if (i<programData.Count)
                {
                    //printing
                    if (lexeme == "TALK TO THE HAND")
                    {
                        nextLexeme = programData.ElementAt(i + 1).Item1;
                        nextLexInfo = programData.ElementAt(i + 1).Item2;
                        nextLineNum = programData.ElementAt(i + 1).Item3;

                        //check nextLine if VAR or STRING
                        if (nextLexInfo == "STR") //if string
                        {
                            //add to GUIActions for printing
                            GUIActions.Add(new Tuple<string, string>("PRINT", nextLexeme));
                        }
                        else if (nextLexInfo=="VAR")
                        {
                            //
                        }
                    }
                    //variable declaration
                    else if (lexeme=="HEY CHRISTMAS TREE")
                    {
                        nextLexeme = programData.ElementAt(i + 1).Item1;
                        nextLexInfo = programData.ElementAt(i + 1).Item2;
                        nextLineNum = programData.ElementAt(i + 1).Item3;

                        //check if next line is VAR
                        if (nextLexInfo == "VAR")
                        {
                            String variable = nextLexeme;
                            String value = programData.ElementAt(i + 3).Item1;

                            nextLexInfo = programData.ElementAt(i + 3).Item2;
                            nextLineNum = programData.ElementAt(i + 3).Item3;

                            if (symbolTableList == null)
                            {
                                //add to symboltable list
                                symbolTableList.Add(new Tuple<string, string>(variable, value));
                            }
                            else
                            {
                                Boolean varExist = false;
                                //check if VAR is existing in symbol  table list
                                for(int STi=0; STi < symbolTableList.Count; STi++)
                                {
                                    if (symbolTableList.ElementAt(STi).Item1 == variable)
                                    {
                                        varExist = true;
                                    }
                                }

                                if (varExist == false)
                                {
                                    //add to symboltable list
                                    symbolTableList.Add(new Tuple<string, string>(variable, value));
                                }
                                else
                                {
                                    error = (new Tuple<bool, string, int>(true, "Line [" + lineNum.ToString() + "] " + variable + " is already used after keyword 'HEY CHRISTMAS TREE'.", lineNum));
                                    Console.WriteLine(error);
                                }
                            }
                        }
                    }
                }
            }
        }

        public Tuple<Boolean, String, int> getError()
        {
            return error;
        }

        public List<Tuple<String, String>> getGUIActions()
        {
            return GUIActions;
        }

        public List<Tuple<String, String>> getSymbolTableList()
        {
            return symbolTableList;
        }
    }
}
