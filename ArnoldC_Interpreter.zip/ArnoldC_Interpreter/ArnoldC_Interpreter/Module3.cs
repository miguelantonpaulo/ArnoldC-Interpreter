﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArnoldC_Interpreter
{
    class Module3
    {

        Tuple<Boolean, String, int> error = new Tuple<bool, string, int>(false, String.Empty, 0);
        List<Tuple<String, String>> GUIActions = new List<Tuple<string, string>>();
        List<Tuple<String, String>> symbolTableList = new List<Tuple<string, string>>();

        public void SemanticAnalysis(List<Tuple<String, String, int>> dataForSemanticAnalyzer)
        {
            List<Tuple<String, String, int>>programData = dataForSemanticAnalyzer;
            int programStart = 0;
            int programEnd = 0;

            //locate blocks
            //program blocks
            for (int i = 0; i < programData.Count; i++)
            {
                String lexeme = programData.ElementAt(i).Item1;
                int lineNum = programData.ElementAt(i).Item3;
                //locate IT'S SHOWTIME
                if (lexeme== "IT'S SHOWTIME")
                {
                    programStart = lineNum;
                }
                //locate YOU HAVE BEEN TERMINATED
                else if (lexeme == "YOU HAVE BEEN TERMINATED")
                {
                    programEnd = lineNum;
                }
            }

            //functions

            //program
            for (int i = 0; i<programData.Count; i++)
            {
                String lexeme = programData.ElementAt(i).Item1;
                String lexInfo = programData.ElementAt(i).Item2;
                int lineNum = programData.ElementAt(i).Item3;

                String nextLexeme;
                String nextLexInfo;
                int nextLineNum;

                if (lexeme == "IT'S SHOWTIME")
                {

                }
            }
        }

        public Tuple<Boolean, String, int> getError()
        {
            return error;
        }

        public List<Tuple<String, String>> getGUIActions()
        {
            return GUIActions;
        }

        public List<Tuple<String, String>> getSymbolTableList()
        {
            return symbolTableList;
        }
    }
}
