﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ArnoldC_Interpreter
{
    public partial class mainEditorTB : Form
    {
        //lexical analyzer declarations
        String code;
        Module1 mod1;
        List<Tuple<String, String, string, int>> tokens;
        List<Tuple<String, String, int>> rejects;

        //semantic analyzer declarations
        Module2 mod2;

        public mainEditorTB()
        {
            InitializeComponent();
        }

        private void browseButton_Click(object sender, EventArgs e)
        {

            OpenFileDialog openFileDialog1 = new OpenFileDialog();

            openFileDialog1.InitialDirectory = @"C:\";

            openFileDialog1.CheckFileExists = true;
            openFileDialog1.CheckPathExists = true;

            openFileDialog1.DefaultExt = "arnoldc";
            openFileDialog1.Filter = "(*.arnoldc)|*.arnoldc";
            openFileDialog1.FilterIndex = 2;
            openFileDialog1.RestoreDirectory = true;

            openFileDialog1.ReadOnlyChecked = true;
            openFileDialog1.ShowReadOnly = true;

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                fileAddressTBox.Text = openFileDialog1.FileName;

                System.IO.StreamReader sr = new
                System.IO.StreamReader(openFileDialog1.FileName);

                //Read the first line of text
                String line = sr.ReadLine();

                //Continue to read until you reach end of file
                while (line != null)
                {
                    //write the lie to console window
                    editorTBox.AppendText(line + "\n");
                    //Read the next line
                    line = sr.ReadLine();
                }

                sr.Close();
            }

        }

        private void runButton_Click(object sender, EventArgs e)
        {
            //Start lexixal analysis
            mod1 = new Module1();
            code = editorTBox.Text;

            outputTBox.AppendText("Lexical Analyzer Running...\n");
            //functions
            mod1.LexicalAnalysis(code);
            tokens = mod1.getTokens();
            rejects = mod1.getRejects();

            //add tokens to tables
            for (int i = 0; i < tokens.Count; i++)
            {
                string[] row = { tokens.ElementAt(i).Item1, tokens.ElementAt(i).Item2 };
                LexerSymbolTable.Rows.Add(row);

            }
            
            if (rejects != null)
            {
                //print all rejected matches
                for (int i = 0; i < rejects.Count; i++)
                {
                    outputTBox.AppendText("ERROR at line " + rejects.ElementAt(i).Item3 + ": " + "'" + rejects.ElementAt(i).Item1 + "' " + "has no match!\n");
                }
            }
            else
            {
                mod2 = new Module2();
                outputTBox.AppendText("Syntax Analyzer Running...\n");
                //start syntax analysis
                mod2.SyntaAnalysis(tokens);
            }

                /*
                //split textinput perline and store in array lines
                textInput = editorTBox.Text;
                line = textInput.Split('\n');

                //start lexical analysis
                for (int i = 0; i < line.Length; i++)
                {
                    if (line.ElementAt(i) != "")//skips new lines
                    {
                        mod1.startLexicalAnalysis(line.ElementAt(i), i);
                        Console.WriteLine(line.ElementAt(i));
                    }
                }

                //get data from lexical analyzer

                tokens = mod1.getData();

                //add lexemes and keywords to respective lists
                for (int j = 0; j < tokens.Count; j++)
                {
                    Tuple<String, String, int> token = tokens.ElementAt(j);

                    if (token.Item2 == "--nomatch--")
                    {
                        Console.WriteLine("Token: " + token.Item1);
                        if(token.Item1.Equals(String.Empty))
                        {
                            tokens.RemoveAt(j);
                        }
                        else
                        {
                            outputTBox.AppendText("ERROR at line " + token.Item3 + ": " + "'" + token.Item1 + "' " + "has no match!\n");
                        }
                    }
                    else
                    {
                        lexemes.Add(token.Item1);
                        keywords.Add(token.Item2);
                        lineNum.Add(token.Item3);
                    }
                }

                //add tokens to tables
                for (int i = 0; i < lexemes.Count; i++)
                {
                    string[] row = { lexemes.ElementAt(i), keywords.ElementAt(i) };
                    LexerSymbolTable.Rows.Add(row);

                }
                */

                //syntax analysis

            }

        private void LexerSymbolTable_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void SymbolTable_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void mainEditorTB_Load(object sender, EventArgs e)
        {

        }
    }
}
