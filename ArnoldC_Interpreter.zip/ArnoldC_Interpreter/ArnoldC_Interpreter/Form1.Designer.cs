﻿namespace ArnoldC_Interpreter
{
    partial class mainEditorTB
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.fileAddressTBox = new System.Windows.Forms.TextBox();
            this.browseButton = new System.Windows.Forms.Button();
            this.editorTBox = new System.Windows.Forms.TextBox();
            this.runButton = new System.Windows.Forms.Button();
            this.saveFileDialog1 = new System.Windows.Forms.SaveFileDialog();
            this.outputTBox = new System.Windows.Forms.TextBox();
            this.LexerSymbolTable = new System.Windows.Forms.DataGridView();
            this.lexemeColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.keywordColumn = new System.Windows.Forms.DataGridViewTextBoxColumn();
            ((System.ComponentModel.ISupportInitialize)(this.LexerSymbolTable)).BeginInit();
            this.SuspendLayout();
            // 
            // fileAddressTBox
            // 
            this.fileAddressTBox.Enabled = false;
            this.fileAddressTBox.Location = new System.Drawing.Point(13, 13);
            this.fileAddressTBox.Name = "fileAddressTBox";
            this.fileAddressTBox.Size = new System.Drawing.Size(273, 20);
            this.fileAddressTBox.TabIndex = 0;
            // 
            // browseButton
            // 
            this.browseButton.Location = new System.Drawing.Point(292, 13);
            this.browseButton.Name = "browseButton";
            this.browseButton.Size = new System.Drawing.Size(75, 23);
            this.browseButton.TabIndex = 1;
            this.browseButton.Text = "Browse";
            this.browseButton.UseVisualStyleBackColor = true;
            this.browseButton.Click += new System.EventHandler(this.browseButton_Click);
            // 
            // editorTBox
            // 
            this.editorTBox.Location = new System.Drawing.Point(13, 40);
            this.editorTBox.Multiline = true;
            this.editorTBox.Name = "editorTBox";
            this.editorTBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.editorTBox.Size = new System.Drawing.Size(429, 396);
            this.editorTBox.TabIndex = 2;
            // 
            // runButton
            // 
            this.runButton.Location = new System.Drawing.Point(367, 13);
            this.runButton.Name = "runButton";
            this.runButton.Size = new System.Drawing.Size(75, 23);
            this.runButton.TabIndex = 3;
            this.runButton.Text = "Run";
            this.runButton.UseVisualStyleBackColor = true;
            this.runButton.Click += new System.EventHandler(this.runButton_Click);
            // 
            // outputTBox
            // 
            this.outputTBox.Location = new System.Drawing.Point(13, 442);
            this.outputTBox.Multiline = true;
            this.outputTBox.Name = "outputTBox";
            this.outputTBox.ReadOnly = true;
            this.outputTBox.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.outputTBox.Size = new System.Drawing.Size(959, 121);
            this.outputTBox.TabIndex = 5;
            // 
            // LexerSymbolTable
            // 
            this.LexerSymbolTable.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.LexerSymbolTable.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.lexemeColumn,
            this.keywordColumn});
            this.LexerSymbolTable.Location = new System.Drawing.Point(449, 13);
            this.LexerSymbolTable.Name = "LexerSymbolTable";
            this.LexerSymbolTable.Size = new System.Drawing.Size(523, 423);
            this.LexerSymbolTable.TabIndex = 6;
            // 
            // lexemeColumn
            // 
            this.lexemeColumn.HeaderText = "Lexemes";
            this.lexemeColumn.Name = "lexemeColumn";
            this.lexemeColumn.Width = 200;
            // 
            // keywordColumn
            // 
            this.keywordColumn.HeaderText = "Keywords";
            this.keywordColumn.Name = "keywordColumn";
            this.keywordColumn.Width = 200;
            // 
            // mainEditorTB
            // 
            this.ClientSize = new System.Drawing.Size(984, 575);
            this.Controls.Add(this.LexerSymbolTable);
            this.Controls.Add(this.outputTBox);
            this.Controls.Add(this.runButton);
            this.Controls.Add(this.editorTBox);
            this.Controls.Add(this.browseButton);
            this.Controls.Add(this.fileAddressTBox);
            this.Name = "mainEditorTB";
            ((System.ComponentModel.ISupportInitialize)(this.LexerSymbolTable)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.TextBox fileAddressTBox;
        private System.Windows.Forms.Button browseButton;
        private System.Windows.Forms.TextBox editorTBox;
        private System.Windows.Forms.Button runButton;
        private System.Windows.Forms.SaveFileDialog saveFileDialog1;
        private System.Windows.Forms.TextBox outputTBox;
        private System.Windows.Forms.DataGridView LexerSymbolTable;
        private System.Windows.Forms.DataGridViewTextBoxColumn lexemeColumn;
        private System.Windows.Forms.DataGridViewTextBoxColumn keywordColumn;
    }
}

