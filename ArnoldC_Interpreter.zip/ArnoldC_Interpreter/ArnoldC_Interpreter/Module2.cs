﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArnoldC_Interpreter
{
    
    class Module2
    {
        List<Tuple<String, String>> codePerLine = new List<Tuple<string, string>>();
        //grammar
        //delimiters
        //Tuple<String, String, List<String>, String, String> DEL1 = new Tuple<string, string, List<string>, string, string>("IT'S SHOWTIME", "linebreak", "<statement>", "linebreak", "YOU HAVE BEEN TERMINATED");
        //String[] program = { "[IT'S SHOWTIME][linebreak]<statement>[linebreak][YOU HAVE BEEN TERMINATED]" }; 

        public void SyntaAnalysis(List<Tuple<String, String, String, int>> tokens)
        {

            addLinebreaks(tokens);

            String codeGrammar = String.Empty;

            for(int i=0; i< codePerLine.Count; i++)
            {
                //runGrammarCheck(tokens.ElementAt(i), codeGrammar);
                Console.WriteLine(codePerLine.ElementAt(i));
            }
        }

        public void addLinebreaks(List<Tuple<String, String, String, int>> tokens)
        {
            int prevLineNum = 0;
            for (int i = 0; i < tokens.Count; i++)
            {

                String lexeme = tokens.ElementAt(i).Item1;
                String lexinfo = tokens.ElementAt(i).Item2;
                String type = tokens.ElementAt(i).Item3;
                int lineNum = tokens.ElementAt(i).Item4;

                if (i == 0)
                {
                    codePerLine.Add(new Tuple<string, string> (lexeme, type));
                }
                else
                {
                    if (prevLineNum!=lineNum)
                    {
                        codePerLine.Add(new Tuple<string, string>("LINEBRK", "Line Break"));
                        codePerLine.Add(new Tuple<string, string>(lexeme, type));
                        prevLineNum = lineNum;
                    }
                    else
                    {
                        codePerLine.Add(new Tuple<string, string>(lexeme, type));
                        prevLineNum = lineNum;
                    }
                }
            }
        }

        public void runGrammarCheck(Tuple<String, String, String, int> token, String codeGrammar)
        {
            String lexeme = token.Item1;
            String lexinfo = token.Item2;
            String type = token.Item3;
            int lineNum = token.Item4;

            if (type.Equals("program"))
            {
                if (codeGrammar.Equals(String.Empty))
                {
                    codeGrammar = codeGrammar + "[" + lexeme + "]";
                }
                else
                {

                }
            }
            else
            {

            }
        }
    }
}
