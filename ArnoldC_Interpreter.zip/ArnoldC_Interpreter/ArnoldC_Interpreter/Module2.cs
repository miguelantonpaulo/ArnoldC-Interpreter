﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArnoldC_Interpreter
{
    
    class Module2
    {
        List<Tuple<String, String, int>> codePerLine = new List<Tuple<string, string, int>>();
        Tuple<Boolean, String, int> error = new Tuple<bool, string, int>(false, String.Empty, 0);
        List<Tuple<String, String, int>> dataForSemanticAnalyzer = new List<Tuple<string, string, int>>(); 

        public void SyntaAnalysis(List<Tuple<String, String, String, int>> tokens)
        {

            addLinebreaks(tokens);
            runGrammarCheck(codePerLine);

            for (int i = 0; i < codePerLine.Count; i++)
            {
                //runGrammarCheck(tokens.ElementAt(i), codeGrammar);
                Console.WriteLine(codePerLine.ElementAt(i));
            }

            for (int i=0; i< dataForSemanticAnalyzer.Count; i++)
            {
                //runGrammarCheck(tokens.ElementAt(i), codeGrammar);
                Console.WriteLine(dataForSemanticAnalyzer.ElementAt(i));
            }
        }

        public void addLinebreaks(List<Tuple<String, String, String, int>> tokens)
        {
            int prevLineNum = 0;
            for (int i = 0; i < tokens.Count; i++)
            {

                String lexeme = tokens.ElementAt(i).Item1;
                String lexinfo = tokens.ElementAt(i).Item2;
                String type = tokens.ElementAt(i).Item3;
                int lineNum = tokens.ElementAt(i).Item4;

                if (i == 0)
                {
                    codePerLine.Add(new Tuple<string, string, int> (lexeme, type, lineNum+1));
                }
                else
                {
                    if (prevLineNum!=lineNum)
                    {
                        codePerLine.Add(new Tuple<string, string, int>("LINEBRK", "Line Break", 0));
                        codePerLine.Add(new Tuple<string, string, int>(lexeme, type, lineNum + 1));
                        prevLineNum = lineNum;
                    }
                    else
                    {
                        codePerLine.Add(new Tuple<string, string, int>(lexeme, type, lineNum + 1));
                        prevLineNum = lineNum;
                    }
                }
            }
        }

        public void runGrammarCheck(List<Tuple<String, String, int>> codePerLine)
        {

            for (int i = 0; i < codePerLine.Count; i++)
            {
                String lexeme = codePerLine.ElementAt(i).Item1;
                String lexinfo = codePerLine.ElementAt(i).Item2;
                int lineNum = codePerLine.ElementAt(i).Item3;

                String nextLexeme;
                String nextLexInfo;
                int nextLineNum;

                if (i == 0)
                {

                    //program
                    //IT’S SHOWTIME<linebreak><statement><linebreak>YOU HAVE BEEN TERMINATED<method>
                    if (lexeme != "IT'S SHOWTIME")
                    {
                        error=(new Tuple<bool, string, int>(true, "Line [" + lineNum.ToString() + "] " + "Missing program delimiter 'IT'S SHOWTIME'.", lineNum));
                        //Console.WriteLine(error);
                    }
                    else
                    {
                        //check if nextLexeme is LINEBRK
                        nextLexeme = codePerLine.ElementAt(i+1).Item1;
                        if(nextLexeme == "LINEBRK")
                        {
                            Boolean delimiterFound = false;
                            //find program delimiter YOU HAVE BEEN TERMINATED
                            for(int j=0; j<codePerLine.Count; j++)
                            {
                                if(codePerLine.ElementAt(j).Item1== "YOU HAVE BEEN TERMINATED")
                                {
                                    delimiterFound = true;
                                }
                            }

                            if (delimiterFound == false)
                            {
                                error=(new Tuple<bool, string, int>(true, "Line [" + lineNum.ToString() + "] " + "Missing program delimiter 'YOU HAVE BEEN TERMINATED' after 'IT'S SHOWTIME'.", lineNum));
                                //Console.WriteLine(error);
                            }
                            else //if delimiter found, add to dataForSemanticAnalyzer
                            {
                                dataForSemanticAnalyzer.Add(new Tuple<string, string, int>(lexeme, lexinfo, lineNum));
                            }
                        }
                        else
                        {
                            error=(new Tuple<bool, string, int>(true, "Line [" + lineNum.ToString() + "] " + "No line break found after 'IT'S SHOWTIME'.", lineNum));
                            //Console.WriteLine(error);
                        }
                    }
                }
                else
                {
                    if (i < codePerLine.Count)
                    {
                        //TALK TO THE HAND<variable|string>
                        if (lexeme == "TALK TO THE HAND")
                        {
                            dataForSemanticAnalyzer.Add(new Tuple<string, string, int>(lexeme, lexinfo, lineNum));

                            nextLexeme = codePerLine.ElementAt(i+1).Item1;
                            nextLexInfo = codePerLine.ElementAt(i+1).Item2;
                            nextLineNum = codePerLine.ElementAt(i + 1).Item3;

                            //check if next lexeme is STR or VAR
                            if (nextLexInfo == "STR")
                            {
                                //add to dataForSemanticAnalyzer
                                dataForSemanticAnalyzer.Add(new Tuple<string, string, int>(nextLexeme, nextLexInfo, nextLineNum));
                            }
                            else if(nextLexInfo == "VAR")
                            {
                                //add to dataForSemanticAnalyzer
                                dataForSemanticAnalyzer.Add(new Tuple<string, string, int>(nextLexeme, nextLexInfo, nextLineNum));
                            }
                            else
                            {
                                error = (new Tuple<bool, string, int>(true, "Line [" + lineNum.ToString() + "] " + nextLexeme + " is neither a String nor a Variable, after keyword 'TALK TO THE HAND'.", lineNum));
                                Console.WriteLine(error);
                            }
                        }
                        //HEY CHRISTMAS TREE variable <linebreak> YOU SET US UP <string|integer|macro>
                        else if (lexeme== "HEY CHRISTMAS TREE")
                        {
                            dataForSemanticAnalyzer.Add(new Tuple<string, string, int>(lexeme, lexinfo, lineNum));

                            nextLexeme = codePerLine.ElementAt(i + 1).Item1;
                            nextLexInfo = codePerLine.ElementAt(i + 1).Item2;
                            nextLineNum = codePerLine.ElementAt(i + 1).Item3;

                            //check if nextLexeme is STR or INT or MAC
                            if(nextLexInfo == "VAR")
                            {
                                //add to dataForSemanticAnalyzer
                                dataForSemanticAnalyzer.Add(new Tuple<string, string, int>(nextLexeme, nextLexInfo, nextLineNum));

                                nextLexeme = codePerLine.ElementAt(i + 2).Item1;
                                nextLexInfo = codePerLine.ElementAt(i + 2).Item2;
                                nextLineNum = codePerLine.ElementAt(i + 2).Item3;

                                //check if nextlexeme is LINEBRK
                                if (nextLexeme== "LINEBRK")
                                {
                                    nextLexeme = codePerLine.ElementAt(i + 3).Item1;
                                    nextLexInfo = codePerLine.ElementAt(i + 3).Item2;
                                    nextLineNum = codePerLine.ElementAt(i + 3).Item3;

                                    //check if nextlexeme is YOU SET US UP
                                    if (nextLexeme== "YOU SET US UP")
                                    {
                                        //add to dataForSemanticAnalyzer
                                        dataForSemanticAnalyzer.Add(new Tuple<string, string, int>(nextLexeme, nextLexInfo, nextLineNum));

                                        nextLexeme = codePerLine.ElementAt(i + 4).Item1;
                                        nextLexInfo = codePerLine.ElementAt(i + 4).Item2;
                                        nextLineNum = codePerLine.ElementAt(i + 4).Item3;

                                        //check if next lexeme is STRING, INT, MACRO
                                        if (nextLexInfo=="STR")
                                        {
                                            //add to dataForSemanticAnalyzer
                                            dataForSemanticAnalyzer.Add(new Tuple<string, string, int>(nextLexeme, nextLexInfo, nextLineNum));
                                        }else if (nextLexInfo == "INT")
                                        {
                                            //add to dataForSemanticAnalyzer
                                            dataForSemanticAnalyzer.Add(new Tuple<string, string, int>(nextLexeme, nextLexInfo, nextLineNum));
                                        }
                                        else if (nextLexInfo == "MAC")
                                        {
                                            //add to dataForSemanticAnalyzer
                                            dataForSemanticAnalyzer.Add(new Tuple<string, string, int>(nextLexeme, nextLexInfo, nextLineNum));
                                        }
                                        else
                                        {
                                            error = (new Tuple<bool, string, int>(true, "Line [" + lineNum.ToString() + "] " + nextLexeme + " is not a String or a Variable or a Macro after keyword 'YOU SET US UP'.", lineNum));
                                            Console.WriteLine(error);
                                        }
                                    }
                                    else
                                    {
                                        error = (new Tuple<bool, string, int>(true, "Line [" + lineNum.ToString() + "] Missing keyword 'YOU SET US UP' after 'HEY CHRISTMAS TREE'", lineNum));
                                        Console.WriteLine(error);
                                    }
                                }
                                else
                                {
                                    error = (new Tuple<bool, string, int>(true, "Line [" + lineNum.ToString() + "] No line break found after 'HEY CHRISTMAS TREE [VAR]'", lineNum));
                                    Console.WriteLine(error);
                                }
                            }
                            else
                            {
                                if(nextLexeme== "LINEBRK")
                                {
                                    error = (new Tuple<bool, string, int>(true, "Line [" + lineNum.ToString() + "] Missing variable after keyword 'HEY CHRISTMAS TREE'.", lineNum));
                                    Console.WriteLine(error);
                                }
                                else
                                {
                                    error = (new Tuple<bool, string, int>(true, "Line [" + lineNum.ToString() + "] " + nextLexeme + " is not a Variable after keyword 'HEY CHRISTMAS TREE'.", lineNum));
                                    Console.WriteLine(error);
                                }
                            }
                        }




                        else if (lexeme == "YOU HAVE BEEN TERMINATED")
                        {
                            dataForSemanticAnalyzer.Add(new Tuple<string, string, int>(lexeme, lexinfo, lineNum));
                        }
                    }
                }
            }
        }

        public Tuple<Boolean, String, int> getError()
        {
            return error;
        }

        public List<Tuple<String, String, int>> getDataForSemanticAnalyzer()
        {
            return dataForSemanticAnalyzer;
        }
    }
}
