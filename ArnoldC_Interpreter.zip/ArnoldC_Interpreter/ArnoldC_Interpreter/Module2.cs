﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArnoldC_Interpreter
{
    
    class Module2
    {
        List<Tuple<String, String, int>> codePerLine = new List<Tuple<string, string, int>>();
        Tuple<Boolean, String, int> error = new Tuple<bool, string, int>(false, String.Empty, 0);
        List<Tuple<String, String, int>> dataForSemanticAnalyzer = new List<Tuple<string, string, int>>(); 

        public void SyntaAnalysis(List<Tuple<String, String, String, int>> tokens)
        {

            addLinebreaks(tokens);
            runGrammarCheck(codePerLine);

            for (int i = 0; i < codePerLine.Count; i++)
            {
                //runGrammarCheck(tokens.ElementAt(i), codeGrammar);
                Console.WriteLine(codePerLine.ElementAt(i));
            }

            for (int i=0; i< dataForSemanticAnalyzer.Count; i++)
            {
                //runGrammarCheck(tokens.ElementAt(i), codeGrammar);
                Console.WriteLine(dataForSemanticAnalyzer.ElementAt(i));
            }
        }

        public void addLinebreaks(List<Tuple<String, String, String, int>> tokens)
        {
            int prevLineNum = 0;
            for (int i = 0; i < tokens.Count; i++)
            {

                String lexeme = tokens.ElementAt(i).Item1;
                String lexinfo = tokens.ElementAt(i).Item2;
                String type = tokens.ElementAt(i).Item3;
                int lineNum = tokens.ElementAt(i).Item4;

                if (i == 0)
                {
                    codePerLine.Add(new Tuple<string, string, int> (lexeme, type, lineNum+1));
                }
                else
                {
                    if (prevLineNum!=lineNum)
                    {
                        codePerLine.Add(new Tuple<string, string, int>("LINEBRK", "Line Break", 0));
                        codePerLine.Add(new Tuple<string, string, int>(lexeme, type, lineNum + 1));
                        prevLineNum = lineNum;
                    }
                    else
                    {
                        codePerLine.Add(new Tuple<string, string, int>(lexeme, type, lineNum + 1));
                        prevLineNum = lineNum;
                    }
                }
            }
        }

        public void runGrammarCheck(List<Tuple<String, String, int>> codePerLine)
        {

            for (int i = 0; i < codePerLine.Count; i++)
            {
                String lexeme = codePerLine.ElementAt(i).Item1;
                String lexinfo = codePerLine.ElementAt(i).Item2;
                int lineNum = codePerLine.ElementAt(i).Item3;

                String nextLexeme;
                String nextLexInfo;
                int nextLineNum;

                if (i == 0)
                {

                    //program
                    //IT’S SHOWTIME<linebreak><statement><linebreak>YOU HAVE BEEN TERMINATED<method>
                    if (lexeme != "IT'S SHOWTIME")
                    {
                        error=(new Tuple<bool, string, int>(true, "Line [" + lineNum.ToString() + "] " + "Missing program delimiter 'IT'S SHOWTIME'.", lineNum));
                        //Console.WriteLine(error);
                    }
                    else
                    {
                        //check if nextLexeme is LINEBRK
                        nextLexeme = codePerLine.ElementAt(i+1).Item1;
                        if(nextLexeme == "LINEBRK")
                        {
                            Boolean delimiterFound = false;
                            //find program delimiter YOU HAVE BEEN TERMINATED
                            for(int j=0; j<codePerLine.Count; j++)
                            {
                                if(codePerLine.ElementAt(j).Item1== "YOU HAVE BEEN TERMINATED")
                                {
                                    delimiterFound = true;
                                }
                            }

                            if (delimiterFound == false)
                            {
                                error=(new Tuple<bool, string, int>(true, "Line [" + lineNum.ToString() + "] " + "Missing program delimiter 'YOU HAVE BEEN TERMINATED' after 'IT'S SHOWTIME'.", lineNum));
                                //Console.WriteLine(error);
                            }
                            else //if delimiter found, add to dataForSemanticAnalyzer
                            {
                                dataForSemanticAnalyzer.Add(new Tuple<string, string, int>(lexeme, lexinfo, lineNum));
                            }
                        }
                        else
                        {
                            error=(new Tuple<bool, string, int>(true, "Line [" + lineNum.ToString() + "] " + "No line break found after 'IT'S SHOWTIME'.", lineNum));
                            //Console.WriteLine(error);
                        }
                    }
                }
                else
                {
                    if (i < codePerLine.Count)
                    {
                        //TALK TO THE HAND<variable|string>
                        if (lexeme == "TALK TO THE HAND")
                        {
                            dataForSemanticAnalyzer.Add(new Tuple<string, string, int>(lexeme, lexinfo, lineNum));

                            nextLexeme = codePerLine.ElementAt(i + 1).Item1;
                            nextLexInfo = codePerLine.ElementAt(i + 1).Item2;
                            nextLineNum = codePerLine.ElementAt(i + 1).Item3;

                            //check if next lexeme is STR or VAR
                            if (nextLexInfo == "STR")
                            {
                                //add to dataForSemanticAnalyzer
                                dataForSemanticAnalyzer.Add(new Tuple<string, string, int>(nextLexeme, nextLexInfo, nextLineNum));
                            }
                            else if (nextLexInfo == "VAR")
                            {
                                //add to dataForSemanticAnalyzer
                                dataForSemanticAnalyzer.Add(new Tuple<string, string, int>(nextLexeme, nextLexInfo, nextLineNum));
                            }
                            else
                            {
                                error = (new Tuple<bool, string, int>(true, "Line [" + lineNum.ToString() + "] " + nextLexeme + " is neither a String nor a Variable, after keyword 'TALK TO THE HAND'.", lineNum));
                                Console.WriteLine(error);
                            }
                        }
                        //HEY CHRISTMAS TREE variable <linebreak> YOU SET US UP <string|integer|macro>
                        else if (lexeme == "HEY CHRISTMAS TREE")
                        {
                            dataForSemanticAnalyzer.Add(new Tuple<string, string, int>(lexeme, lexinfo, lineNum));

                            nextLexeme = codePerLine.ElementAt(i + 1).Item1;
                            nextLexInfo = codePerLine.ElementAt(i + 1).Item2;
                            nextLineNum = codePerLine.ElementAt(i + 1).Item3;

                            //check if nextLexeme is STR or INT or MAC
                            if (nextLexInfo == "VAR")
                            {
                                //add to dataForSemanticAnalyzer
                                dataForSemanticAnalyzer.Add(new Tuple<string, string, int>(nextLexeme, nextLexInfo, nextLineNum));

                                nextLexeme = codePerLine.ElementAt(i + 2).Item1;
                                nextLexInfo = codePerLine.ElementAt(i + 2).Item2;
                                nextLineNum = codePerLine.ElementAt(i + 2).Item3;

                                //check if nextlexeme is LINEBRK
                                if (nextLexeme == "LINEBRK")
                                {
                                    nextLexeme = codePerLine.ElementAt(i + 3).Item1;
                                    nextLexInfo = codePerLine.ElementAt(i + 3).Item2;
                                    nextLineNum = codePerLine.ElementAt(i + 3).Item3;

                                    //check if nextlexeme is YOU SET US UP
                                    if (nextLexeme == "YOU SET US UP")
                                    {
                                        //add to dataForSemanticAnalyzer
                                        dataForSemanticAnalyzer.Add(new Tuple<string, string, int>(nextLexeme, nextLexInfo, nextLineNum));

                                        nextLexeme = codePerLine.ElementAt(i + 4).Item1;
                                        nextLexInfo = codePerLine.ElementAt(i + 4).Item2;
                                        nextLineNum = codePerLine.ElementAt(i + 4).Item3;

                                        //check if next lexeme is STRING, INT, MACRO
                                        if (nextLexInfo == "STR")
                                        {
                                            //add to dataForSemanticAnalyzer
                                            dataForSemanticAnalyzer.Add(new Tuple<string, string, int>(nextLexeme, nextLexInfo, nextLineNum));
                                        }
                                        else if (nextLexInfo == "INT")
                                        {
                                            //add to dataForSemanticAnalyzer
                                            dataForSemanticAnalyzer.Add(new Tuple<string, string, int>(nextLexeme, nextLexInfo, nextLineNum));
                                        }
                                        else if (nextLexInfo == "MAC")
                                        {
                                            //add to dataForSemanticAnalyzer
                                            dataForSemanticAnalyzer.Add(new Tuple<string, string, int>(nextLexeme, nextLexInfo, nextLineNum));
                                        }
                                        else
                                        {
                                            error = (new Tuple<bool, string, int>(true, "Line [" + lineNum.ToString() + "] " + nextLexeme + " is not a String or a Variable or a Macro after keyword 'YOU SET US UP'.", lineNum));
                                            Console.WriteLine(error);
                                        }
                                    }
                                    else
                                    {
                                        error = (new Tuple<bool, string, int>(true, "Line [" + lineNum.ToString() + "] Missing keyword 'YOU SET US UP' after 'HEY CHRISTMAS TREE'", lineNum));
                                        Console.WriteLine(error);
                                    }
                                }
                                else
                                {
                                    error = (new Tuple<bool, string, int>(true, "Line [" + lineNum.ToString() + "] No line break found after 'HEY CHRISTMAS TREE [VAR]'", lineNum));
                                    Console.WriteLine(error);
                                }
                            }
                            else
                            {
                                if (nextLexeme == "LINEBRK")
                                {
                                    error = (new Tuple<bool, string, int>(true, "Line [" + lineNum.ToString() + "] Missing variable after keyword 'HEY CHRISTMAS TREE'.", lineNum));
                                    Console.WriteLine(error);
                                }
                                else
                                {
                                    error = (new Tuple<bool, string, int>(true, "Line [" + lineNum.ToString() + "] " + nextLexeme + " is not a Variable after keyword 'HEY CHRISTMAS TREE'.", lineNum));
                                    Console.WriteLine(error);
                                }
                            }
                        }
                        else if (lexeme == "@I LIED") // macro for I LIED
                        {
                            dataForSemanticAnalyzer.Add(new Tuple<string, string, int>(lexeme, lexinfo, lineNum));

                            nextLexeme = codePerLine.ElementAt(i + 1).Item1;
                            nextLexInfo = codePerLine.ElementAt(i + 1).Item2;
                            nextLineNum = codePerLine.ElementAt(i + 1).Item3;
                        }

                        else if (lexeme == "@NO PROBLEMO") // macro for NO PROBLEMO
                        {
                            dataForSemanticAnalyzer.Add(new Tuple<string, string, int>(lexeme, lexinfo, lineNum));

                            nextLexeme = codePerLine.ElementAt(i + 1).Item1;
                            nextLexInfo = codePerLine.ElementAt(i + 1).Item2;
                            nextLineNum = codePerLine.ElementAt(i + 1).Item3;
                        }
                        // GET TO THE CHOPPER variable <linebreak> HERE IS MY INVITATION <operations> ENOUGH TALK
                        else if (lexeme == "GET TO THE CHOPPER")
                        {
                            dataForSemanticAnalyzer.Add(new Tuple<string, string, int>(lexeme, lexinfo, lineNum));

                            nextLexeme = codePerLine.ElementAt(i + 1).Item1;
                            nextLexInfo = codePerLine.ElementAt(i + 1).Item2;
                            nextLineNum = codePerLine.ElementAt(i + 1).Item3;
                            // check if the next lexeme is a variable
                            if (nextLexeme == "VAR")
                            {
                                //add to dataForSemanticAnalyzer
                                dataForSemanticAnalyzer.Add(new Tuple<string, string, int>(nextLexeme, nextLexInfo, nextLineNum));

                                nextLexeme = codePerLine.ElementAt(i + 2).Item1;
                                nextLexInfo = codePerLine.ElementAt(i + 2).Item2;
                                nextLineNum = codePerLine.ElementAt(i + 2).Item3;
                                //check if the next lexeme is a Line Break
                                if (nextLexeme == "LINEBRK")
                                {

                                    nextLexeme = codePerLine.ElementAt(i + 3).Item1;
                                    nextLexInfo = codePerLine.ElementAt(i + 3).Item2;
                                    nextLineNum = codePerLine.ElementAt(i + 3).Item3;
                                    // check if next lexeme is the HERE IS MY INVITATION keyword
                                    if (nextLexeme == "HERE IS MY INVITATION")
                                    {
                                        //add to dataForSemanticAnalyzer
                                        dataForSemanticAnalyzer.Add(new Tuple<string, string, int>(nextLexeme, nextLexInfo, nextLineNum));

                                        nextLexeme = codePerLine.ElementAt(i + 4).Item1;
                                        nextLexInfo = codePerLine.ElementAt(i + 4).Item2;
                                        nextLineNum = codePerLine.ElementAt(i + 4).Item3;

                                        //check if the next lexeme is an operation
                                        if (nextLexeme == "OP") // !!! HELP !!! how do i insert the operators here (<operations>, <operands>, and <operators>)
                                        {
                                            //add to dataForSemanticAnalyzer
                                            dataForSemanticAnalyzer.Add(new Tuple<string, string, int>(nextLexeme, nextLexInfo, nextLineNum));

                                            nextLexeme = codePerLine.ElementAt(i + 5).Item1;
                                            nextLexInfo = codePerLine.ElementAt(i + 5).Item2;
                                            nextLineNum = codePerLine.ElementAt(i + 5).Item3;

                                            //check if the next lexeme is the delimiter ENOUGH TALK
                                            if (nextLexeme == "ENOUGH TALK")
                                            {
                                                //add to dataForSemanticAnalyzer
                                                dataForSemanticAnalyzer.Add(new Tuple<string, string, int>(nextLexeme, nextLexInfo, nextLineNum));
                                            }
                                            else
                                            {
                                                error = (new Tuple<bool, string, int>(true, "Line [" + lineNum.ToString() + "] Missing keyword 'ENOUGH TALK' for 'GET TO THE CHOPPER' starting statement", lineNum));
                                                Console.WriteLine(error);
                                            }
                                        }
                                        else
                                        {
                                            error = (new Tuple<bool, string, int>(true, "Line [" + lineNum.ToString() + "] No Operations found in the var assignment.", lineNum));
                                            Console.WriteLine(error);
                                        }
                                    }
                                    else
                                    {
                                        error = (new Tuple<bool, string, int>(true, "Line [" + lineNum.ToString() + "] Missing keyword 'HERE IS MY INVITATION'.", lineNum));
                                        Console.WriteLine(error);
                                    }

                                }
                                else
                                {
                                    error = (new Tuple<bool, string, int>(true, "Line [" + lineNum.ToString() + "] No Linebreak found after variable statement.", lineNum));
                                    Console.WriteLine(error);
                                }
                            }
                            else {
                                if (nextLexeme == "LINEBRK")
                                {
                                    error = (new Tuple<bool, string, int>(true, "Line [" + lineNum.ToString() + "] Missing variable after keyword 'GET TO THE CHOPPER'.", lineNum));
                                    Console.WriteLine(error);
                                }
                                else
                                {
                                    error = (new Tuple<bool, string, int>(true, "Line [" + lineNum.ToString() + "] " + nextLexeme + " is not a Variable after keyword 'GET TO THE CHOPPER'.", lineNum));
                                    Console.WriteLine(error);
                                }
                            }
                        }
                        // GET YOUR ASS TO MARS variable <linebreak> DO IT NOW <linebreak> I WANT TO ASK YOU A BUNCH OF QUESTIONS AND I WANT TO HAVE THEM ANSWERED IMMEDIATELY
                        else if (lexeme == "GET YOUR ASS TO MARS")
                        {
                            dataForSemanticAnalyzer.Add(new Tuple<string, string, int>(lexeme, lexinfo, lineNum));

                            nextLexeme = codePerLine.ElementAt(i + 1).Item1;
                            nextLexInfo = codePerLine.ElementAt(i + 1).Item2;
                            nextLineNum = codePerLine.ElementAt(i + 1).Item3;

                            if (nextLexeme == "VAR") {
                                dataForSemanticAnalyzer.Add(new Tuple<string, string, int>(nextLexeme, nextLexInfo, nextLineNum));

                                nextLexeme = codePerLine.ElementAt(i + 2).Item1;
                                nextLexInfo = codePerLine.ElementAt(i + 2).Item2;
                                nextLineNum = codePerLine.ElementAt(i + 2).Item3;

                                if (nextLexeme == "LINEBRK") {
                                    nextLexeme = codePerLine.ElementAt(i + 3).Item1;
                                    nextLexInfo = codePerLine.ElementAt(i + 3).Item2;
                                    nextLineNum = codePerLine.ElementAt(i + 3).Item3;

                                    if (nextLexeme == "DO IT NOW")
                                    {
                                        dataForSemanticAnalyzer.Add(new Tuple<string, string, int>(nextLexeme, nextLexInfo, nextLineNum));

                                        nextLexeme = codePerLine.ElementAt(i + 4).Item1;
                                        nextLexInfo = codePerLine.ElementAt(i + 4).Item2;
                                        nextLineNum = codePerLine.ElementAt(i + 4).Item3;
                                        
                                        if(nextLexeme == "LINEBRK")
                                        {
                                            nextLexeme = codePerLine.ElementAt(i + 5).Item1;
                                            nextLexInfo = codePerLine.ElementAt(i + 5).Item2;
                                            nextLineNum = codePerLine.ElementAt(i + 5).Item3;
                                            
                                            if(nextLexeme == "I WANT TO ASK YOU A BUNCH OF QUESTIONS AND I WANT TO HAVE THEM ANSWERED IMMEDIATELY")
                                            {
                                                dataForSemanticAnalyzer.Add(new Tuple<string, string, int>(nextLexeme, nextLexInfo, nextLineNum));
                                                
                                            } else
                                            {
                                                error = (new Tuple<bool, string, int>(true, "Line [" + lineNum.ToString() + "] Missing keyword 'I WANT TO ASK YOU A BUNCH OF QUESTIONS AND I WANT TO HAVE THEM ANSWERED IMMEDIATELY' for 'GET YOUR ASS TO MARS' starting statement", lineNum));
                                                Console.WriteLine(error);
                                            }
                                        } else
                                        {
                                            error = (new Tuple<bool, string, int>(true, "Line [" + lineNum.ToString() + "] No Linebreak found after 'DO IT NOW'.", lineNum));
                                            Console.WriteLine(error);
                                        }
                                    } else
                                    {
                                        error = (new Tuple<bool, string, int>(true, "Line [" + lineNum.ToString() + "] Missing keyword 'DO IT NOW'.", lineNum));
                                        Console.WriteLine(error);
                                    }
                                } else
                                {
                                    error = (new Tuple<bool, string, int>(true, "Line [" + lineNum.ToString() + "] Line break expected.", lineNum));
                                    Console.WriteLine(error);
                                }
                            } else
                            {
                                if (nextLexeme == "LINEBRK")
                                {
                                    error = (new Tuple<bool, string, int>(true, "Line [" + lineNum.ToString() + "] Missing variable after keyword 'GET YOUR ASS TO MARS'.", lineNum));
                                    Console.WriteLine(error);
                                }
                                else
                                {
                                    error = (new Tuple<bool, string, int>(true, "Line [" + lineNum.ToString() + "] " + nextLexeme + " is not a Variable after keyword 'GET YOUR ASS TO MARS'.", lineNum));
                                    Console.WriteLine(error);
                                }
                            }

                        } 
                        // BECAUSE I'M GOING TO SAY PLEASE <if-actions> YOU HAVE NO RESPECT FOR LOGIC
                        else if (lexeme == "BECAUSE I'M GOING TO SAY PLEASE")
                        {
                            dataForSemanticAnalyzer.Add(new Tuple<string, string, int>(lexeme, lexinfo, lineNum));

                            nextLexeme = codePerLine.ElementAt(i + 1).Item1;
                            nextLexInfo = codePerLine.ElementAt(i + 1).Item2;
                            nextLineNum = codePerLine.ElementAt(i + 1).Item3;
                            
                            if(nextLexeme == "IF-ACTIONS")
                            {
                                dataForSemanticAnalyzer.Add(new Tuple<string, string, int>(nextLexeme, nextLexInfo, nextLineNum));

                                nextLexeme = codePerLine.ElementAt(i + 2).Item1;
                                nextLexInfo = codePerLine.ElementAt(i + 2).Item2;
                                nextLineNum = codePerLine.ElementAt(i + 2).Item3;

                                if(nextLexeme == "YOU HAVE NO RESPECT FOR LOGIC")
                                {
                                    dataForSemanticAnalyzer.Add(new Tuple<string, string, int>(nextLexeme, nextLexInfo, nextLineNum));
                                } else
                                {
                                    error = (new Tuple<bool, string, int>(true, "Line [" + lineNum.ToString() + "] Missing keyword 'YOU HAVE NO RESPECT FOR LOGIC' for 'BECAUSE I'M GOING TO SAY PLEASE' starting statement", lineNum));
                                    Console.WriteLine(error);
                                }
                            } else
                            {
                                if (nextLexeme == "LINEBRK")
                                {
                                    error = (new Tuple<bool, string, int>(true, "Line [" + lineNum.ToString() + "] Variable expected after keyword 'BECAUSE I'M GOING TO SAY PLEASE'.", lineNum));
                                    Console.WriteLine(error);
                                }
                                else
                                {
                                    error = (new Tuple<bool, string, int>(true, "Line [" + lineNum.ToString() + "] " + nextLexeme + " is not a Variable after keyword 'BECAUSE I'M GOING TO SAY PLEASE'.", lineNum));
                                    Console.WriteLine(error);
                                }
                            } 
                        }

                        // BULLSHIT <linebreak> <statement> <linebreak>
                        else if (lexeme == "BULLSHIT")
                        {
                            dataForSemanticAnalyzer.Add(new Tuple<string, string, int>(lexeme, lexinfo, lineNum));

                            nextLexeme = codePerLine.ElementAt(i + 1).Item1;
                            nextLexInfo = codePerLine.ElementAt(i + 1).Item2;
                            nextLineNum = codePerLine.ElementAt(i + 1).Item3;

                            if(nextLexeme == "LINEBRK")
                            {
                                nextLexeme = codePerLine.ElementAt(i + 2).Item1;
                                nextLexInfo = codePerLine.ElementAt(i + 2).Item2;
                                nextLineNum = codePerLine.ElementAt(i + 2).Item3;
                                // insert code for statement?? please help HAHAHA how do I insert <statement> here
                            }
                        }




                        else if (lexeme == "YOU HAVE BEEN TERMINATED")
                        {
                            dataForSemanticAnalyzer.Add(new Tuple<string, string, int>(lexeme, lexinfo, lineNum));
                        }
                    }
                }
            }
        }

        public Tuple<Boolean, String, int> getError()
        {
            return error;
        }

        public List<Tuple<String, String, int>> getDataForSemanticAnalyzer()
        {
            return dataForSemanticAnalyzer;
        }
    }
}
